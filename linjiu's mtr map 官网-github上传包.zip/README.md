# linjiu's mtr route map — 官网

Minecraft Transit Railway 的交通地图与换乘规划模组官网。

- 支持版本：Minecraft 1.20.1（Forge 47.x / Fabric）
- MTR 兼容：3.2 ~ 3.6（不支持 4.0+）
- 作者：smile_linjiu
- 许可：MIT

## 部署

本仓库为纯静态站点，开启 GitHub Pages 即可：
Settings → Pages → Source: Deploy from a branch → main / (root)

## 反馈 / 加群

- QQ 群 ①：1121207406
- QQ 群 ②：1070364321